/*
    AUTHOR: Nick Marquis
    FILE: server.js
    ASSIGNMENT: PA 10
    COURSE: CSc 337; Summer 2021
    PURPOSE: This file contains the JavaScript for a a web server that allows for users 
    to have an account, log in, and then post, view, and purchase items for sale synced 
    across devices.
    It uses a Mongo database to sync the users and items, and a URL path to get and create them.
*/
const express = require('express');
const mongoose = require('mongoose');
const parser = require('body-parser');
const cookieParser = require('cookie-parser');

const app = express();
app.use(parser.json());
app.use(parser.urlencoded({ extended: true }));
app.use(cookieParser());


const db = mongoose.connection;
const mongoDBURL = 'mongodb://localhost/auto';

app.use(express.static('public_html'))

const port = 80;
app.listen(port, () => {
    console.log('server has started');
});

function updateSessions() {
    console.log('session update function');
    let now = Date.now();
    for (e in sessionKeys) {
      if (sessionKeys[e][1] < (now - 6000000)) {
        delete sessionKeys[e];
      }
    }
  }
  
setInterval(updateSessions, 2000);

var Schema = mongoose.Schema;
var Items_Schema = new Schema({
    title: String,
    description: String,
    image: String,
    price: Number,
    stat: String
});

var Items = mongoose.model('Items', Items_Schema );

var Users_Schema = new Schema({
    username: String,
    password: String,
    listings: [{ type: Schema.Types.ObjectId, ref: 'Items' }],
    purchases: [{ type: Schema.Types.ObjectId, ref: 'Items' }]
});

var Users = mongoose.model('Users', Users_Schema );

var sessionKeys = {};

mongoose.connect(mongoDBURL , { useNewUrlParser: true });
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

app.use('/index.html', express.static('public_html/index'));
app.use('/user.html', authenticate);
app.use('/', express.static('public_html'));

/*
    Purpose: Returns a JSON array containing the information for every user in the database.
*/
app.get('/get/users/', function (req, res) {
    Users.find({})
    .exec(function(error, results) {
      res.send(JSON.stringify(results));
     });
});

/*
    Purpose: Returns a JSON array containing the information for every item in the database.
*/
app.get('/get/items/', function (req, res) {
    Items.find({})
    .exec(function(error, results) {
      res.send(JSON.stringify(results));
     });
});

/*
    Purpose: Returns a JSON array containing every listing(item) for the given user.
*/
app.get('/get/listings/:USERNAME', function (req, res) {
    Users.find({username: req.params.USERNAME})
    .exec(function(error, results) {
        res.send(JSON.stringify(results[0].listings));
    });
});

/*
    Purpose: Returns a JSON array containing every purchase(item) for the given user.
*/
app.get('/get/purchases/:USERNAME', function (req, res) {
    Users.find({username: req.params.USERNAME})
    .exec(function(error, results) {
        res.send(JSON.stringify(results[0].purchases));
    });
});

/*
    Purpose: Returns a JSON list of every user whose username has the given substring.
*/
app.get('/search/users/:KEYWORD', function (req, res) {
    Users.find({username: { "$regex": req.params.KEYWORD, "$options": "i" }})
    .exec(function(error, results) {
        res.send(JSON.stringify(results));
    });
});

/*
    Purpose: Returns a JSON list of every item whose description has the given substring.
*/
app.get('/search/items/:KEYWORD', function (req, res) {
    console.log(authenticate(req, res));
    if (authenticate(req, res) == 'OK') {
        Items.find({description: { "$regex": req.params.KEYWORD, "$options": "i" }})
        .exec(function(error, results) {
            console.log(results);
            res.send(results);
        });
    } else {
        res.send('NOT ALLOWED');
    }
});

/*
    Purpose: Adds a User object to the database.
*/
app.post('/add/user/', function (req, res) {
    let userObject = JSON.parse(req.body.user);
    Users.find({username: userObject.username})
    .exec(function(error, results) {
        if (results.length == 0) {
            var user = new Users(userObject);
            user.save(function (err) { if (err) console.log('an error occurred'); });
            res.send('User created');
        } else {
            res.send('Username taken');
        }
    });
});

/*
    Purpose: Adds an Item object to the database and assigns it to a User object's listings.
*/
app.post('/add/item/', function (req, res) {
    if (authenticate(req, res) == 'OK') {
        let itemObject = JSON.parse(req.body.item);
        console.log(req.body);
        console.log(itemObject);
        var item = new Items(itemObject);
        item.save(function (err) { if (err) console.log('an error occurred'); });
        Users.find({username: req.cookies.loginStatus.username})
        .exec(function(error, results) {
            results[0].listings.push(item);
            results[0].save(function (err) { if (err) console.log('an error occurred'); });
        });
    } else {
        res.send('NOT ALLOWED');
    }
});

/*
    Purpose: Checks a username and password. If valid, logs in user and creates session cookie.
*/
app.get('/login/:USERNAME/:PASS', function (req, res) {
    Users.find({username: req.params.USERNAME, password: req.params.PASS})
    .exec(function(error, results) {
        if (results.length == 1) {
            let sessionKey = Math.floor(Math.random() * 10000);
            sessionKeys[req.params.USERNAME] = sessionKey;
            res.cookie('loginStatus', {username: req.params.USERNAME, key: sessionKey}, {maxAge: 6000000});
            res.send(req.params.USERNAME);
        } else {
            res.send('login failed');
        }
    });
});

/*
    Purpose: Returns local session cookie if one exists
*/
app.get('/getcookie', function (req, res) {
    console.log(req.cookies)
    res.send(req.cookies);
});

/*
    Purpose: Checks if session cookie has expired.
*/
app.get('/authenticate', function (req, res) {
    res.send(authenticate(req, res));
});

/*
    Purpose: Checks if session cookie has expired.
    @returns: a string of 'OK' if the session cookie has not expired,
                or 'NOT ALLOWED' otherwise
*/
function authenticate(req, res) {
    if (Object.keys(sessionKeys) == 0) {
        return('NOT ALLOWED');
    } else if (sessionKeys[req.cookies.loginStatus.username] == req.cookies.loginStatus.key) {
        let u = req.cookies.loginStatus.username;
        let key = req.cookies.loginStatus.key;
        if ( Object.keys(sessionKeys).length > 0 && sessionKeys[u] == key) {
            return('OK');
        } else {
            return('NOT ALLOWED');
        }
        } else {
            return('NOT ALLOWED');
    }
}

/*
    Purpose: Returns the user's listings
*/
app.get('/get/listings/', function (req, res) {
    console.log(authenticate(req, res));
    if (authenticate(req, res) == 'OK') {
        Users.find({username: req.cookies.loginStatus.username})
        .populate('listings')
        .exec(function(error, results) {
            console.log(results[0].listings);
            res.send(results[0].listings);
        });
    } else {
        res.send('NOT ALLOWED');
    }
});

/*
    Purpose: Returns the user's purchases
*/
app.get('/get/purchases/', function (req, res) {
    console.log(authenticate(req, res));
    if (authenticate(req, res) == 'OK') {
        Users.find({username: req.cookies.loginStatus.username})
        .populate('purchases')
        .exec(function(error, results) {
            console.log(results[0].purchases);
            res.send(results[0].purchases);
        });
    } else {
        res.send('NOT ALLOWED');
    }
});

/*
    Purpose: Marks an item as sold and adds it to the user's purchases
*/
app.post('/buy/item/:ID', function (req, res) {
    Items.find({_id: req.params.ID})
    .exec(function(error, results) {
        var item = results[0];
        item.stat = 'SOLD';
        item.save(function (err) { if (err) console.log('an error occurred'); });
        Users.find({username: req.cookies.loginStatus.username})
        .exec(function(error, result) {
            var user = result[0];
            user.purchases.push(item);
            user.save(function (err) { if (err) console.log('an error occurred'); });
        });
    });
});