/*
    AUTHOR: Nick Marquis
    FILE: client.js
    ASSIGNMENT: PA 10
    COURSE: CSc 337; Summer 2021
    PURPOSE: This file contains the JavaScript which manages the user and item databases.
*/

/*
    Purpose: Adds a User object to the database.
*/
function addUser() {
    let n = $('#createUsername').val();
    let p = $('#createPassword').val();
    let list = new Array();
    let pur = new Array();
    let user = {username:n, password:p, listings:list, purchases:pur }
    let user_str = JSON.stringify(user);
    $.ajax({
        url: '/add/user/',
        data:{user: user_str},
        method:'POST',
        success: function( result ) {
            alert(result);
        }
    });
}

/*
    Purpose: Adds an Item object to the database and assigns it to a User object's listings.
*/
function addItem() {
    $.ajax({
        url: '/authenticate',
        method:'GET',
        success: function( result ) {
            if (result == 'NOT ALLOWED') {
                let url = '/index.html';
                window.location = url;
                alert('Please log in');
            } else {
                let t = $('#title').val();
                let d = $('#desc').val();
                let i = $('#image').val();
                let p = $('#price').val();
                let s = $('#status').val();
                let u = $('#username').val();
                let item = {title: t,
                    description: d,
                    image: i,
                    price: p,
                    stat: s}
                let item_str = JSON.stringify(item);
                $.ajax({
                    url: '/add/item/',
                    data:{item: item_str},
                    method:'POST',
                    success: function( result ) {
                        console.log(result);
                    }
                });
                let url = '/home.html';
                window.location = url;
            }
        }
    });
}

/*
    Purpose: Returns a JSON array containing the information for every item in the database.
*/
function getItems() {
    $.ajax({
        url: '/get/items/',
        method:'GET',
        success: function( result ) {
            console.log(result);
        }
    });
}

/*
    Purpose: Returns a JSON array containing the information for every user in the database.
*/
function getUsers() {
    $.ajax({
        url: '/get/users/',
        method:'GET',
        success: function( result ) {
            console.log(result);
          }
    });
}

/*
    Purpose: Returns a JSON array containing every listing(item) for the given user.
*/
function getUserListings() {
    let n = $('#getUserListings').val();
    $.ajax({
        url: '/get/listings/'+n,
        method:'GET',
        success: function( result ) {
            console.log(result);
          }
    });
}

/*
    Purpose: Returns a JSON array containing every purchase(item) for the given user.
*/
function getUserPurchases() {
    let n = $('#getUserPurchases').val();
    $.ajax({
        url: '/get/purchases/'+n,
        method:'GET',
        success: function( result ) {
            console.log(result);
          }
    });
}

/*
    Purpose: Returns a JSON list of every user whose username has the given substring.
*/
function searchUsers() {
    let n = $('#searchUsers').val();
    $.ajax({
        url: '/search/users/'+n,
        method:'GET',
        success: function( result ) {
            console.log(result);
          }
    });
}

/*
    Purpose: Returns a JSON list of every item whose description has the given substring.
*/
function searchItems() {
    let n = $('#searchItems').val();
    $.ajax({
        url: '/search/items/'+n,
        method:'GET',
        success: function( result ) {
            if (result == 'NOT ALLOWED') {
                let url = '/index.html';
                window.location = url;
                alert('Please log in');
            } else {
                let results = displayResult(result);
                $('#itemsDiv').html(results);                
            }
          }
    });
}

/*
    Purpose: Attempts to log in a user.
            If successful, sends user to home page
            If unsuccessful, notifies user
*/
function login() {
    let n = $('#loginUsername').val();
    let p = $('#loginPassword').val();
    $.ajax({
        url: '/login/'+n+'/'+p,
        method:'GET',
        success: function( result ) {
            if (result == 'login failed') {
                alert('login failed')
            } else {
                console.log(result);
                let url = '/home.html';
                window.location = url;
            }
        }
    });
}

/*
    Purpose: Updates the welcome text with the user's username
*/
function updateWelcome() {
    $.ajax({
        url: '/getcookie',
        method:'GET',
        success: function( result ) {
            console.log(result);
            console.log(result.loginStatus.username);
            $('#welcome').text('Welcome '+result.loginStatus.username+'! What would you like to do?'); 
        }
    });
}

/*
    Purpose: Gets the listings of the user if the session cookie has not expired
            If unsuccessful, prompts user to log in and sends them to the login page
*/
function getListings() {
    $.ajax({
        url: '/get/listings/',
        method:'GET',
        success: function( result ) {
            if (result == 'NOT ALLOWED') {
                let url = '/index.html';
                window.location = url;
                alert('Please log in');
            } else {
                let results = displayResult(result);
                $('#itemsDiv').html(results);                
            }
        }
    });
}

/*
    Purpose: Gets the purchases of the user if the session cookie has not expired
            If unsuccessful, prompts user to log in and sends them to the login page
*/
function getPurchases() {
    $.ajax({
        url: '/get/purchases/',
        method:'GET',
        success: function( result ) {
            if (result == 'NOT ALLOWED') {
                let url = '/index.html';
                window.location = url;
                alert('Please log in');
            } else {
                let results = displayResult(result);
                $('#itemsDiv').html(results);                
            }
        }
    });
}

/*
    Purpose: Sends the user to the item posting page if the session cookie has not expired
            If unsuccessful, prompts user to log in and sends them to the login page
*/
function goToPost() {
    $.ajax({
        url: '/authenticate',
        method:'GET',
        success: function( result ) {
            if (result == 'NOT ALLOWED') {
                let url = '/index.html';
                window.location = url;
                alert('Please log in');
            } else {
                let url = '/post.html';
                window.location = url;
            }
        }
    });
}

/*
    Purpose: Formats the JSON data for display
    @params: data, a JSON list
    @returns: a formatted HTML string
*/
function displayResult(data) {
    var toReturn = '';
    for (i in data) {
        var id = data[i]._id;
        toReturn += '<div class="item">';
        toReturn += '<p class="itemTitle">' + data[i].title + '</p>';
        toReturn += '<p class="itemImage">' + data[i].image + '</p>';          
        toReturn += '<p class="itemDesc">' + data[i].description + '</p>';
        toReturn += '<p class="itemPrice">' + '$' + data[i].price + '</p>';
        if (data[i].stat == 'SALE') {
            toReturn += '<input type="button" class="itemBuyNow" onclick="buy('+"'"+id+"'"+');" value="Buy Now!"/>';
        } else {
            toReturn += '<p class="itemSold">' + 'SOLD' + '</p>';
        }
        toReturn += '</div>';
    }
    console.log('toReturn');
    console.log(toReturn);
    
    return toReturn;
}

/*
    Purpose: Sets an item to sold, adds to the user's purchases
    @params: id, the item id
*/
function buy(id) {
    $.ajax({
        url: '/buy/item/'+id,
        method:'POST',
        success: function( result ) {
            console.log('bought!');
          }
    });
}